const sourcemap = require("@dcloudio/uni-stacktracey");
module.exports = {
	sourcemap
};
